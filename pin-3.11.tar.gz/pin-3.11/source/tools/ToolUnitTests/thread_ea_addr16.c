/*
 * Copyright 2002-2019 Intel Corporation.
 * 
 * This software is provided to you as Sample Source Code as defined in the accompanying
 * End User License Agreement for the Intel(R) Software Development Products ("Agreement")
 * section 1.L.
 * 
 * This software and the related documents are provided as is, with no express or implied
 * warranties, other than those that are expressly stated in the License.
 */

#include <assert.h>
#include <stdio.h>
#include "../Utils/threadlib.h"

/* Test handling of 16bit addressing, including supplying 16bit address IARG_MEMOREY(READ/WRITE)_EA
   to tool
*/
#if defined(__cplusplus)
extern "C"
#endif
void Test_addr16 ();

int a[100000];
int n = 10;

#ifdef TARGET_WINDOWS
extern __declspec(dllexport) __declspec(noinline)
#endif
void * longfun(void * arg)
{
    int i,j;
    
    for (j = 0; j < 1000; j++)
    {
        for (i = 0; i < n; i++)
        {
            a[i] = 1;
        }
    }
    Test_addr16 ();
    return 0;
}


#ifdef TARGET_WINDOWS
extern __declspec(dllexport) __declspec(noinline)
#endif
void * shortfun(void * arg)
{
    a[1] = 1;
    Test_addr16 ();
    return 0;
}

THREAD_HANDLE threads[MAXTHREADS];

int main(int argc, char *argv[])
{
    int numthreads = 0;
    int i;
    
    Test_addr16 ();
    numthreads = 30;
    assert(numthreads < MAXTHREADS);
    
    for (i = 0; i < numthreads; i++)
    {
        printf("Creating thread %d\n", i);
        fflush(stdout);
        if (i % 2 == 0)
            CreateOneThread(&threads[i], longfun, 0);
        else
            CreateOneThread(&threads[i], shortfun, 0);
    }
    for (i = 0; i < numthreads; i++)
    {
        BOOL success;
        success = JoinOneThread(threads[i]);
        if (!success)
        {
            fprintf(stdout, "JoinOneThread failed\n");
            fflush (stdout);
        }
    }
    
    
    printf("All threads joined\n");
    fflush (stdout);

    return 0;
}
